package com.example.miniproject2team3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Miniproject2team3Application {

	public static void main(String[] args) {
		SpringApplication.run(Miniproject2team3Application.class, args);
	}

}
